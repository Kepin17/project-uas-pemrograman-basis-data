<?php 

// navIgnore
$navIgnore = [
    "auth/login",
    "auth/register",
    
  ];

define('NAV_IGNORE' , $navIgnore);  
?>